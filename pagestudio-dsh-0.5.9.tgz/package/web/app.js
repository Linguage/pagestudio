'use strict';
const $ = (id) => document.getElementById(id);
const pending = '待归类';
const colors = {
  '工程技术':['#557c91','#e9f0f4','#263947'], 'AI 技术':['#70679d','#eeecf6','#38324d'],
  '内容创作':['#9e7650','#f4eee3','#423526'], '个人发展':['#8d6559','#f2e7df','#44342f'],
  '思想与人文':['#a96c83','#f5eaf0','#453140'], '其他':['#7e7669','#eee8dc','#3b352e'],
  '待归类':['#907e6c','#f0ede7','#3c3530']
};
let category = '', page = 1, state, editing, importing = false;
let activeRequest, timer, dragDepth = 0;
let readerItem, readerRequest, readerSource;
let summaryEditor;
const method = {pending:'待归类', auto:'自动归类', ai:'AI 归类', manual:'手工整理', archive:'原卡片库分类'};
const chatChannel = 'dsh-html-cards-discussion';
const appearanceKey = 'pagestudio-appearance';
let discussionAvailable = false;
let storageBusy = false;
let storageFixed = false;
let release;
let checkingRelease = false;
let installingRelease = false;
let releaseChecked = false;
const starterHtml = `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>我的笔记</title>
</head>
<body>
  <h1>我的笔记</h1>
  <p>从这里开始写。</p>
</body>
</html>`;

function el(tag, name, text) {
  const node = document.createElement(tag);
  if (name) node.className = name;
  if (text != null) node.textContent = text;
  return node;
}
function tint(node, cat) {
  if (!Object.hasOwn(colors, cat)) return;
  const palette = colors[cat];
  const [dot, light, dark] = palette;
  node.style.setProperty('--tint', dot);
  node.style.setProperty('--chip', light);
  node.style.setProperty('--chip-dark', dark);
}
function followTheme() {
  let host;
  try {
    if (window.parent !== window) host = window.parent.document.body;
  } catch { /* Standalone and cross-origin previews use the system theme. */ }
  const media = matchMedia('(prefers-color-scheme: dark)');
  const options = $('appearanceOptions');
  function readPreference() {
    try {
      const saved = JSON.parse(localStorage.getItem(appearanceKey));
      options.elements.appearance.value = saved?.appearance === 'retro' ? 'retro' : 'song';
      options.elements.mode.value = ['light', 'dark'].includes(saved?.mode) ? saved.mode : 'auto';
    } catch {
      options.elements.appearance.value = 'song';
      options.elements.mode.value = 'auto';
    }
  }
  const sync = () => {
    const { appearance, mode } = options.elements;
    const systemDark = host ? host.hasAttribute('data-ds-dark-theme') : media.matches;
    const dark = mode.value === 'auto' ? systemDark : mode.value === 'dark';
    document.documentElement.dataset.appearance = appearance.value;
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    syncReaderTheme();
    syncWorkspaceTheme();
  };
  $('appearanceButton').onclick = () => $('appearanceDialog').showModal();
  options.addEventListener('change', () => {
    const { appearance, mode } = options.elements;
    try {
      localStorage.setItem(appearanceKey, JSON.stringify({ appearance: appearance.value, mode: mode.value }));
    } catch { /* Still apply the preference in the current window. */ }
    sync();
  });
  const observer = host ? new MutationObserver(sync) : null;
  if (observer) observer.observe(host, { attributes: true, attributeFilter: ['data-ds-dark-theme'] });
  else media.addEventListener('change', sync);
  window.addEventListener('storage', event => {
    if (event.key === appearanceKey || event.key === null) {
      readPreference();
      sync();
    }
  });
  readPreference();
  sync();
  window.addEventListener('pagehide', event => {
    if (event.persisted) return;
    observer?.disconnect();
    media.removeEventListener('change', sync);
  });
}
function activeAppearance() {
  const { theme, appearance } = document.documentElement.dataset;
  return { theme, appearance };
}
function syncWorkspaceTheme() {
  if (window.parent !== window) updateHost('appearance', activeAppearance());
}
function message(id, text, error = false) {
  $(id).textContent = text;
  $(id).hidden = !text;
  $(id).classList.toggle('error', error);
}
async function request(path, options = {}) {
  const response = await fetch(path, options);
  const data = await response.json();
  if (!response.ok) throw Object.assign(Error(data.error || '操作未完成'), { status: response.status });
  return data;
}
function post(path, body, contentType) {
  const headers = {'X-HTML-Cards':'local'};
  if (contentType) headers['Content-Type'] = contentType;
  return request(path, {method:'POST', headers, body});
}
function setStorageBusy(busy) {
  storageBusy = busy;
  for (const id of ['storagePath', 'browseStorage', 'createStorage', 'openStorage']) {
    $(id).disabled = busy || storageFixed;
  }
}
async function openStorageSettings() {
  const dialog = $('storageDialog');
  dialog.showModal();
  message('storageStatus', '');
  setStorageBusy(true);
  try {
    const info = await request('./api/storage', {headers: {'X-HTML-Cards':'local'}});
    storageFixed = info.fixed;
    $('storagePath').value = info.directory;
    message('storageStatus', info.error || (storageFixed ? '当前路径由启动配置指定。' : ''), Boolean(info.error));
  } catch (error) {
    message('storageStatus', error.message, true);
  } finally {
    setStorageBusy(false);
  }
}
$('storageButton').onclick = openStorageSettings;
$('browseStorage').onclick = () => {
  setStorageBusy(true);
  updateHost('browse-storage');
};
$('storageForm').onsubmit = async event => {
  event.preventDefault();
  if (storageBusy || storageFixed) return;
  if (importing) return message('storageStatus', '文件正在导入，请稍后再试。', true);
  const directory = $('storagePath').value;
  const create = event.submitter?.value === 'create';
  setStorageBusy(true);
  message('storageStatus', '');
  try {
    await post('./api/storage', JSON.stringify({directory, create}), 'application/json');
    $('storageDialog').close();
    $('search').value = '';
    category = '';
    page = 1;
    message('status', create ? '已新建资料库。' : '已切换资料库。');
    await refresh();
  } catch (error) {
    message('storageStatus', error.message, true);
  } finally {
    setStorageBusy(false);
  }
};
async function refresh() {
  activeRequest?.abort();
  const ctrl = new AbortController();
  activeRequest = ctrl;
  const params = new URLSearchParams({q:$('search').value, category, page});
  try {
    const result = await request('./api/cards?' + params, {signal:ctrl.signal});
    if (ctrl.signal.aborted) return;
    state = result;
    if (category && !result.categories.includes(category)) return select('');
    if (page > 1 && !result.cards.length) {
      page = Math.max(1, Math.ceil(result.total / 30));
      await refresh();
      return;
    }
    render();
  } catch (error) {
    if (error.name !== 'AbortError') message('status', '读取资料库失败：' + error.message, true);
  }
}
function select(cat) {
  category = cat;
  page = 1;
  refresh();
}
function render() {
  const all = Object.values(state.counts).reduce((a,b) => a + b, 0);
  const label = category || '全部文件';
  $('location').textContent = label;
  $('heading').textContent = label;
  $('count').textContent = state.total + ' 个文件';
  $('categories').replaceChildren(...['', ...state.categories].map(cat => {
    const b = el('button', 'nav-item');
    b.append(el('span', 'swatch'), el('span', '', cat || '全部文件'),
             el('span', 'nav-count', cat ? state.counts[cat] || 0 : all));
    b.setAttribute('aria-current', String(cat === category));
    b.onclick = () => select(cat);
    tint(b, cat);
    return b;
  }));
  const cards = state.cards.map(makeCard);
  if (!cards.length) {
    const box = el('div', 'empty');
    if ($('search').value.trim()) box.append(el('strong','', '没有找到匹配的文件'), el('span','', '试试另一个关键词。'));
    else if (category) box.append(el('strong','', '这个分类暂时没有文件'), el('span','', category === pending ? '新建和导入的文件会出现在这里。' : '整理待归类卡片后，归到这一类的文件会出现在这里。'));
    else box.append(el('strong','', '书架还是空的'), el('span','', '把 .html 或 .htm 文件拖进来，开始收集。'));
    cards.push(box);
  }
  $('cards').replaceChildren(...cards);
  const last = Math.max(1, Math.ceil(state.total / 30));
  $('pages').hidden = last === 1;
  $('pageLabel').textContent = page + ' / ' + last;
  $('prev').disabled = page === 1;
  $('next').disabled = page === last;
}

function confirmAction(title, description, label, action) {
  $('confirmTitle').textContent = title;
  $('confirmText').textContent = description;
  $('confirmSubmit').textContent = label;
  message('confirmStatus', '');
  $('confirmForm').onsubmit = async event => {
    event.preventDefault();
    $('confirmSubmit').disabled = true;
    try {
      await action();
      $('confirmDialog').close();
    } catch (error) {
      message('confirmStatus', error.message, true);
    } finally {
      $('confirmSubmit').disabled = false;
    }
  };
  $('confirmDialog').showModal();
}

let cancelCategoryRename;
let categoryWrite = false;

async function changeCategory(input, onSaved) {
  if (categoryWrite) throw Error('正在保存分类，请稍后再试。');
  categoryWrite = true;
  try {
    const result = await post('./api/categories', JSON.stringify(input), 'application/json');
    const focusName = onSaved(result);
    await Promise.all([refresh(), loadCategoryList(focusName)]);
  } finally {
    categoryWrite = false;
  }
}

async function loadCategoryList(focusName) {
  const categories = await request('./api/categories');
  if (!$('categoryDialog').open) return;
  $('categoryTotals').textContent = (categories.length - 1) + ' 个可编辑分类 · ' +
    categories.reduce((total, item) => total + item.count, 0) + ' 张卡片';
  cancelCategoryRename = undefined;
  $('categoryList').replaceChildren(...categories.map(makeCategoryRow));
  if (focusName) {
    const buttons = $('categoryList').querySelectorAll('[data-rename]');
    [...buttons].find(button => button.dataset.rename === focusName)?.focus();
  }
}

function makeCategoryRow({ name, count }) {
  const row = el('li', 'category-row');
  tint(row, name);
  const label = el('div', 'category-identity');
  label.append(el('span', 'category-dot'), el('strong', '', name));
  const size = el('span', 'category-size', count + ' 张');
  const actions = el('div', 'category-actions');
  row.append(label, size, actions);
  if (name === pending) {
    row.classList.add('category-system');
    actions.append(el('span', 'category-system-label', '系统分类'));
    return row;
  }
  const rename = el('button', 'secondary category-rename', '重命名');
  rename.type = 'button';
  rename.dataset.rename = name;
  rename.setAttribute('aria-label', '重命名分类 ' + name);
  const remove = el('button', 'edit category-remove', '删除');
  remove.type = 'button';
  remove.setAttribute('aria-label', '删除分类 ' + name);
  actions.append(rename, remove);
  rename.onclick = () => editCategoryName(row, label, actions, rename, name);
  remove.onclick = () => {
    if (categoryWrite) return;
    confirmAction('删除分类', '「' + name + '」中的卡片会移到「待归类」。', '删除分类', () =>
      changeCategory({action: 'remove', name}, ({ moved }) => {
        if (category === name) { category = ''; page = 1; }
        message('categoryStatus', '已删除分类' + (moved ? '，' + moved + ' 张卡片已移到「待归类」' : '') + '。');
      }));
  };
  return row;
}

function editCategoryName(row, label, actions, rename, name) {
  if (categoryWrite) return;
  cancelCategoryRename?.();
  message('categoryStatus', '');
  const form = el('form', 'category-rename-form');
  const input = el('input');
  input.value = name;
  input.maxLength = 40;
  input.required = true;
  input.setAttribute('aria-label', '新的分类名称');
  const save = el('button', 'primary', '保存');
  save.type = 'submit';
  const cancel = el('button', 'secondary', '取消');
  cancel.type = 'button';
  form.append(input, cancel, save);
  row.append(form);
  row.classList.add('category-editing');
  label.hidden = actions.hidden = true;
  const close = () => {
    form.remove();
    row.classList.remove('category-editing');
    label.hidden = actions.hidden = false;
    cancelCategoryRename = undefined;
  };
  cancelCategoryRename = close;
  cancel.onclick = () => { close(); rename.focus(); };
  form.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || save.disabled) return;
    event.preventDefault();
    cancel.click();
  });
  form.onsubmit = async event => {
    event.preventDefault();
    const newName = input.value;
    input.disabled = cancel.disabled = save.disabled = true;
    try {
      await changeCategory({action: 'rename', name, newName}, saved => {
        if (category === name) category = saved.name;
        close();
        message('categoryStatus', '已保存「' + saved.name + '」。');
        return saved.name;
      });
    } catch (error) {
      message('categoryStatus', error.message, true);
    } finally {
      input.disabled = cancel.disabled = save.disabled = false;
      if (input.isConnected) input.focus();
    }
  };
  input.focus();
  input.select();
}

$('manageCategories').onclick = async () => {
  $('categoryName').value = '';
  $('categoryTotals').textContent = '';
  $('categoryList').replaceChildren();
  message('categoryStatus', '正在读取分类…');
  $('categoryDialog').showModal();
  try {
    await loadCategoryList();
    message('categoryStatus', '');
  } catch (error) {
    message('categoryStatus', error.message, true);
  }
};
$('categoryForm').onsubmit = async event => {
  event.preventDefault();
  const button = event.submitter;
  button.disabled = true;
  try {
    await changeCategory({action: 'add', name: $('categoryName').value}, ({ name }) => {
      $('categoryName').value = '';
      message('categoryStatus', '已新建「' + name + '」。');
    });
  } catch (error) {
    message('categoryStatus', error.message, true);
  } finally {
    button.disabled = false;
  }
};
function makeCard(item) {
  const card = el('article', 'card');
  tint(card, item.category);
  const main = el('button', 'card-main');
  main.type = 'button';
  const top = el('div', 'card-top');
  const badge = el('span', 'badge', item.category);
  badge.title = method[item.method];
  top.append(badge, el('span', 'card-format', 'HTML'));
  main.append(top, el('h3', '', item.title), el('p', '', item.summary || item.description || '暂无摘要'));
  main.onclick = () => showReader(item);
  card.append(main);
  if (item.tags.length) {
    const tags = el('div', 'tags');
    for (const tag of item.tags) {
      const chip = el('button', '', tag);
      chip.onclick = () => {$('search').value = tag; select('');};
      tags.append(chip);
    }
    card.append(tags);
  }
  const foot = el('div', 'card-foot');
  const filename = el('span', 'filename', item.filename);
  filename.title = item.filename;
  const edit = el('button', 'edit', '编辑');
  edit.setAttribute('aria-label', '编辑 ' + item.title);
  edit.onclick = () => showEditor(item);
  foot.append(filename, edit);
  card.append(foot);
  return card;
}
let exportAvailable = false;
let exportingId;
function exportMessage(value, error = false) {
  message('exportStatus', value, error);
  $('exportStatus').hidden = !value;
}
function showReader(item) {
  readerItem = item;
  exportMessage(exportingId === item.id ? '正在导出图片…' : '');
  $('exportImages').disabled = Boolean(exportingId);
  summaryEditor = { id: item.id, saved: null, conflict: false, loading: false, saving: false };
  fillDetails({ title: '', tags: [], summary: '' });
  $('summaryCategory').replaceChildren();
  message('summaryStatus', '');
  updateSummaryControls();
  $('readerZoom').textContent = '原始大小';
  $('readerTitle').textContent = item.title;
  $('download').href = './download/' + item.id;
  renderSourceLink();
  reloadReaderFrame();
  selectReaderTab(readerTabs[0]);
  $('reader').showModal();
}
function renderSourceLink() {
  $('source').hidden = !readerItem.canonical;
  if (readerItem.canonical) $('source').href = readerItem.canonical;
  else $('source').removeAttribute('href');
}
function reloadReaderFrame() {
  const params = new URLSearchParams(activeAppearance());
  if (readerSource) params.set('v', readerSource.version);
  $('frame').src = './reader/' + readerItem.id + '?' + params;
  $('readerZoom').textContent = '原始大小';
}
function syncReaderTheme() {
  if (!readerItem) return;
  $('frame').contentWindow?.postMessage({
    channel: 'dsh-html-cards-reader',
    ...activeAppearance(),
  }, '*');
}
$('frame').addEventListener('load', syncReaderTheme);
const readerTabs = [...$('readerTabs').querySelectorAll('[role=tab]')];
function selectReaderTab(selected) {
  for (const tab of readerTabs) {
    const active = tab === selected;
    tab.setAttribute('aria-selected', String(active));
    tab.tabIndex = active ? 0 : -1;
    $(tab.getAttribute('aria-controls')).hidden = !active;
  }
  $('readerZoom').hidden = selected.id !== 'renderTab';
  $('exportImages').hidden = !exportAvailable || selected.id !== 'renderTab';
  if (selected.id === 'summaryTab') loadSummary();
  if ((selected.id === 'codeTab' || selected.id === 'textTab') && !readerRequest) loadReaderSource();
}
for (const tab of readerTabs) tab.onclick = () => selectReaderTab(tab);
$('readerTabs').addEventListener('keydown', event => {
  const index = readerTabs.indexOf(event.target);
  const last = readerTabs.length - 1;
  const next = { ArrowLeft: (index + last) % readerTabs.length, ArrowRight: (index + 1) % readerTabs.length, Home: 0, End: last };
  if (index < 0 || !Object.hasOwn(next, event.key)) return;
  event.preventDefault();
  readerTabs[next[event.key]].focus();
  selectReaderTab(readerTabs[next[event.key]]);
});
const detailInputs = ['summaryTitle', 'summaryCategory', 'summaryTags', 'summaryText'];
function detailsDraft() {
  const tagText = $('summaryTags').value;
  const savedTags = summaryEditor?.saved?.tags;
  const tags = tagText === savedTags?.join('，') ? savedTags :
    [...new Set(tagText.split(/[，,、]/).map(tag => tag.replace(/\s+/g, ' ').trim()).filter(Boolean))];
  return {
    title: $('summaryTitle').value.trim(),
    category: $('summaryCategory').value,
    tags,
    summary: $('summaryText').value.trim(),
  };
}
function sameDetails(a, b) {
  return a.title === b.title && a.category === b.category && a.summary === b.summary &&
    a.tags.length === b.tags.length && a.tags.every((tag, index) => tag === b.tags[index]);
}
function fillDetails(details) {
  $('summaryTitle').value = details.title;
  if (details.category) $('summaryCategory').value = details.category;
  $('summaryTags').value = details.tags.join('，');
  $('summaryText').value = details.summary;
}
function useSavedDetails(editor, saved) {
  editor.saved = saved;
  editor.conflict = false;
  $('summaryCategory').replaceChildren(...saved.categories.map(name => new Option(name, name)));
  fillDetails(saved);
  $('readerTitle').textContent = saved.title;
  readerItem = { ...readerItem, title: saved.title, category: saved.category, tags: saved.tags, summary: saved.summary };
}
function updateSummaryControls() {
  if (!summaryEditor) return;
  const { saved, conflict, saving } = summaryEditor;
  const draft = detailsDraft();
  const count = [...draft.summary].length;
  const dirty = Boolean(saved && !sameDetails(draft, saved));
  const suggestion = saved?.suggestion;
  const disabled = !saved || saving;
  $('summaryCount').textContent = count + ' / 140 字';
  $('summaryCount').toggleAttribute('data-over', count > 140);
  for (const id of detailInputs) $(id).disabled = disabled;
  $('summaryText').setAttribute('aria-invalid', String(count > 140));
  $('copySummary').disabled = !draft.summary || disabled;
  $('pasteSummary').disabled = disabled;
  $('saveSummary').disabled = !dirty || !draft.title || !draft.category || count > 140 || saving || conflict;
  $('generateSummary').disabled = disabled || conflict || dirty;
  $('generateSummary').title = dirty ? '先保存当前编辑' : '在 AI 侧栏发送整理请求';
  $('reloadSummary').hidden = !conflict;
  $('cardSuggestion').hidden = !suggestion || conflict;
  if (suggestion) {
    $('suggestedTitle').textContent = suggestion.title;
    $('suggestedCategory').textContent = suggestion.category;
    $('suggestedTags').textContent = suggestion.tags.join('、') || '无';
    $('suggestedSummary').textContent = suggestion.summary;
    $('fillSuggestion').disabled = saving || dirty || sameDetails(saved, suggestion);
    $('saveSuggestion').disabled = $('fillSuggestion').disabled;
  }
}
async function loadSummary(replace = false) {
  const editor = summaryEditor;
  if (!editor || editor.loading || editor.saving) return;
  editor.loading = true;
  if (!editor.saved) message('summaryStatus', '正在读取卡片资料…');
  try {
    const saved = await request('./api/card/' + editor.id + '/details');
    if (editor !== summaryEditor) return;
    const previous = editor.saved;
    if (replace || !previous || saved.version !== previous.version) {
      editor.conflict = Boolean(!replace && previous && !sameDetails(detailsDraft(), previous));
      if (editor.conflict) {
        message('summaryStatus', '已保存的卡片资料有更新。当前编辑仍保留，可复制后载入新版。', true);
      } else {
        useSavedDetails(editor, saved);
        message('summaryStatus', previous ? '已载入最新卡片资料。' : '');
      }
    } else {
      if (saved.categories.join('\0') !== previous.categories.join('\0')) {
        const selected = $('summaryCategory').value;
        $('summaryCategory').replaceChildren(...saved.categories.map(name => new Option(name, name)));
        $('summaryCategory').value = selected;
      }
      const suggestionChanged = JSON.stringify(saved.suggestion) !== JSON.stringify(previous.suggestion);
      editor.saved = saved;
      if (suggestionChanged && saved.suggestion && !editor.conflict) message('summaryStatus', 'AI 整理建议已就绪。');
    }
    updateSummaryControls();
  } catch (error) {
    if (editor === summaryEditor) message('summaryStatus', error.message, true);
  } finally {
    editor.loading = false;
  }
}
$('summaryForm').addEventListener('input', updateSummaryControls);
$('reloadSummary').onclick = () => loadSummary(true);
$('summaryForm').onsubmit = event => {
  event.preventDefault();
  if (!$('saveSummary').disabled) saveDetails(detailsDraft());
};
$('fillSuggestion').onclick = () => {
  fillDetails(summaryEditor.saved.suggestion);
  updateSummaryControls();
  $('summaryTitle').focus();
  message('summaryStatus', '建议已填入，可继续修改并保存。');
};
$('saveSuggestion').onclick = () => saveDetails(summaryEditor.saved.suggestion);
async function saveDetails(draft) {
  const editor = summaryEditor;
  if (!editor?.saved || editor.saving || editor.conflict) return;
  editor.saving = true;
  updateSummaryControls();
  let stale = false;
  try {
    const saved = await post('./api/card/' + editor.id + '/details',
      JSON.stringify({ ...draft, version: editor.saved.version }), 'application/json');
    refresh();
    if (editor !== summaryEditor) return;
    useSavedDetails(editor, saved);
    message('summaryStatus', '卡片资料已保存。');
  } catch (error) {
    if (editor !== summaryEditor) return;
    stale = error.status === 409;
    message('summaryStatus', error.message, true);
  } finally {
    if (editor === summaryEditor) {
      editor.saving = false;
      updateSummaryControls();
      if (stale) loadSummary();
    }
  }
}
$('copySummary').onclick = async () => {
  const editor = summaryEditor;
  const input = $('summaryText');
  try {
    await navigator.clipboard.writeText(input.value.trim());
    if (editor === summaryEditor) message('summaryStatus', '摘要已复制。');
  } catch {
    if (editor !== summaryEditor) return;
    input.select();
    message('summaryStatus', '已选中摘要，可用复制快捷键。');
  }
};
$('pasteSummary').onclick = async () => {
  const editor = summaryEditor;
  const input = $('summaryText');
  try {
    const text = await navigator.clipboard.readText();
    if (editor !== summaryEditor || input.disabled || !text) return;
    input.setRangeText(text, input.selectionStart, input.selectionEnd, 'end');
    input.focus();
    updateSummaryControls();
  } catch {
    if (editor !== summaryEditor) return;
    input.focus();
    message('summaryStatus', '可在摘要框使用粘贴快捷键。');
  }
};
$('generateSummary').onclick = () => {
  const { id, saved } = summaryEditor;
  openDiscussion('summary', id, saved.version);
  message('summaryStatus', '已准备整理请求，请在 AI 侧栏发送。');
};
function bodyText(source) {
  // Template content stays inert, including images, embedded pages and scripts.
  const template = document.createElement('template');
  template.innerHTML = source;
  const body = template.content;
  for (const node of body.querySelectorAll('head,title,style,script,template,noscript,iframe,object,svg,[hidden]')) node.remove();
  const walker = document.createTreeWalker(body, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    const node = walker.currentNode;
    if (!node.parentElement?.closest('pre')) node.data = node.data.replace(/\s+/g, ' ');
  }
  for (const node of body.querySelectorAll('br,hr')) node.replaceWith('\n');
  for (const node of body.querySelectorAll('address,article,aside,blockquote,dd,details,div,dl,dt,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,li,main,nav,ol,p,pre,section,summary,table,tr,ul')) {
    node.before('\n');
    node.after('\n');
  }
  for (const cell of body.querySelectorAll('td,th')) {
    if (cell.nextElementSibling) cell.after('\t');
  }
  return body.textContent.replace(/\n[ \t]*(?:\n[ \t]*)+/g, '\n\n').trim();
}
async function loadReaderSource() {
  const controller = new AbortController();
  readerRequest = controller;
  $('readerText').textContent = '正在读取…';
  message('sourceStatus', '正在读取源码…');
  try {
    const response = await fetch('./file/' + readerItem.id, { signal: controller.signal });
    const version = response.headers.get('etag')?.match(/^"([a-f0-9]{64})"$/)?.[1];
    if (!response.ok || !version) throw Error('无法读取 HTML 源码');
    const source = await response.text();
    if (controller.signal.aborted) return;
    $('readerCode').value = source;
    readerSource = { version, saved: $('readerCode').value, saving: false };
    $('readerText').textContent = bodyText(source) || '没有可提取的正文。';
    message('sourceStatus', '');
    updateSourceControls();
  } catch (error) {
    if (controller.signal.aborted) return;
    $('readerText').textContent = error.message;
    message('sourceStatus', error.message, true);
    readerRequest = undefined;
  }
}
function sourceDirty() {
  return readerSource && readerSource.saved !== $('readerCode').value;
}
function updateSourceControls() {
  $('readerCode').disabled = !readerSource || readerSource.saving;
  $('resetSource').disabled = $('readerCode').disabled || !sourceDirty();
  $('saveSource').disabled = $('resetSource').disabled || !$('readerCode').value.trim();
}
$('readerCode').oninput = updateSourceControls;
$('resetSource').onclick = () => {
  $('readerCode').value = readerSource.saved;
  message('sourceStatus', '');
  updateSourceControls();
};
$('sourceForm').onsubmit = async event => {
  event.preventDefault();
  if ($('saveSource').disabled) return;
  const editor = readerSource;
  const value = $('readerCode').value;
  editor.saving = true;
  updateSourceControls();
  try {
    const saved = await post('./api/card/' + readerItem.id + '/source?' + new URLSearchParams({version: editor.version}), value, 'text/html; charset=utf-8');
    editor.version = saved.version;
    editor.saved = value;
    readerItem.canonical = saved.canonical;
    renderSourceLink();
    reloadReaderFrame();
    $('readerText').textContent = bodyText(value) || '没有可提取的正文。';
    message('sourceStatus', '源码已保存，HTML 渲染和纯文本已更新。');
    refresh();
    if (summaryEditor?.saved) loadSummary();
  } catch (error) {
    message('sourceStatus', error.message, true);
  } finally {
    editor.saving = false;
    updateSourceControls();
  }
};
function closeReader() {
  if (readerSource?.saving) return;
  if (!sourceDirty()) return $('reader').close();
  confirmAction('放弃源码修改？', '你还有未保存的 HTML 源码修改。', '放弃修改', () => $('reader').close());
}
$('readerZoom').onclick = () => {
  const button = $('readerZoom');
  const fit = button.textContent === '适合宽度';
  $('frame').contentWindow?.postMessage({ channel: 'dsh-html-cards-reader', fit }, '*');
  button.textContent = fit ? '原始大小' : '适合宽度';
};
function showEditor(item) {
  editing = item;
  message('editStatus', '');
  $('editTitle').value = item.title;
  $('editFilename').value = item.filename;
  $('editCategory').replaceChildren(...state.categories.map(cat => new Option(cat, cat)));
  $('editCategory').value = item.category;
  $('editTags').value = item.tags.join('，');
  $('editor').showModal();
}
$('reader').addEventListener('close', () => {
  $('frame').removeAttribute('src');
  readerRequest?.abort();
  readerSource = readerRequest = readerItem = undefined;
  summaryEditor = undefined;
  $('readerCode').value = $('readerText').textContent = '';
  message('sourceStatus', '');
  updateSourceControls();
  $('codePanel').scrollTop = $('textPanel').scrollTop = 0;
  $('codePanel').scrollLeft = 0;
});
$('reader').addEventListener('cancel', event => {
  event.preventDefault();
  closeReader();
});
for (const b of document.querySelectorAll('.close')) {
  b.onclick = () => {
    const dialog = b.closest('dialog');
    if (dialog.id === 'reader') closeReader();
    else if (dialog.id !== 'confirmDialog' || !$('confirmSubmit').disabled) dialog.close();
  };
}
$('confirmDialog').addEventListener('cancel', event => {
  if ($('confirmSubmit').disabled) event.preventDefault();
});
$('create').onclick = () => {
  $('createName').value = '';
  $('createCode').value = starterHtml;
  message('createStatus', '');
  $('creator').showModal();
};
$('createForm').onsubmit = async event => {
  event.preventDefault();
  const submit = event.currentTarget.querySelector('[type=submit]');
  const name = $('createName').value.trim();
  const source = $('createCode').value;
  if (!name || !source.trim()) return message('createStatus', '请填写文件名和 HTML 源码。', true);
  const filename = /\.html?$/i.test(name) ? name : name + '.html';
  submit.disabled = true;
  try {
    const item = await post('./api/create?' + new URLSearchParams({name:filename}), source, 'text/html; charset=utf-8');
    if (item.duplicate) return message('createStatus', '相同的 HTML 已在卡片库中：' + item.filename, true);
    $('creator').close();
    $('search').value = '';
    select(pending);
    message('status', '已创建并加入「待归类」 · ' + item.filename);
    showReader(item);
  } catch (error) {
    message('createStatus', error.message, true);
  } finally {
    submit.disabled = false;
  }
};
$('editForm').onsubmit = async (event) => {
  event.preventDefault();
  const b = event.currentTarget.querySelector('[type=submit]');
  b.disabled = true;
  try {
    await post('./api/card/' + editing.id, JSON.stringify({
      title:$('editTitle').value, category:$('editCategory').value, tags:$('editTags').value.split(/[，,]/),
      filename: $('editFilename').value === editing.filename ? undefined : $('editFilename').value,
    }), 'application/json');
    $('editor').close();
    await refresh();
  } catch (e) {
    message('editStatus', e.message, true);
  } finally {
    b.disabled = false;
  }
};
$('deleteCard').onclick = () => {
  const { id, title } = editing;
  confirmAction('删除卡片', '「' + title + '」及其摘要将从当前资料库永久删除。', '删除卡片', async () => {
    await post('./api/card/' + id + '/delete');
    $('editor').close();
    await refresh();
    message('status', '已删除卡片。');
  });
};
$('search').addEventListener('input', () => {
  clearTimeout(timer);
  page = 1;
  timer = setTimeout(refresh, 160);
});
$('prev').onclick = () => {page--; refresh();};
$('next').onclick = () => {page++; refresh();};
$('pick').onclick = () => $('files').click();
$('pickFolder').onclick = () => $('folder').click();
for (const id of ['files', 'folder']) {
  $(id).onchange = () => {
    const files = [...$(id).files];
    $(id).value = '';
    upload(files);
  };
}
function hasFiles(e) {
  return Array.from(e.dataTransfer?.types || []).includes('Files');
}
document.addEventListener('dragover', e => {if (hasFiles(e)) e.preventDefault();});
document.addEventListener('drop', e => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  upload([...e.dataTransfer.files]);
});
$('drop').addEventListener('dragenter', e => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  dragDepth++;
  $('drop').classList.add('drag');
});
$('drop').addEventListener('dragleave', () => {
  dragDepth = Math.max(0, dragDepth - 1);
  if (!dragDepth) $('drop').classList.remove('drag');
});
$('drop').addEventListener('drop', e => {
  e.preventDefault();
  e.stopPropagation();
  dragDepth = 0;
  $('drop').classList.remove('drag');
  upload([...e.dataTransfer.files]);
});
async function upload(files) {
  if (importing) return;
  const manifests = files.filter(file => file.webkitRelativePath && file.name === 'deck.json');
  const deckRoots = manifests.map(file => file.webkitRelativePath.slice(0, -'deck.json'.length));
  const html = files.filter(file => /\.html?$/i.test(file.name) &&
    !deckRoots.some(root => file.webkitRelativePath.startsWith(root.replace(/\/project\/$/, '/'))));
  if (!html.length && !manifests.length) {
    message('status', '请拖入 .html 或 .htm 文件。整批文件可以用「选择文件夹」导入。', true);
    return;
  }
  importing = $('pick').disabled = $('pickFolder').disabled = true;
  let added = 0, duplicates = 0;
  const errors = [];
  const decks = [];
  for (const [index, manifest] of manifests.entries()) {
    const root = deckRoots[index];
    const form = new FormData();
    form.append('deck.json', manifest);
    for (const file of files) {
      if (!file.webkitRelativePath.startsWith(root)) continue;
      const key = file.webkitRelativePath.slice(root.length);
      if (/^(?:slides|assets|ds)\//.test(key)) form.append(key, file);
    }
    message('status', '正在导入整套幻灯片 · ' + root);
    try {
      const result = await post('./api/import-deck', form);
      if (result.duplicate) duplicates++;
      else added++;
      const missing = result.missingAssets.length ? '，未找到部分资源' : '';
      decks.push(result.title + '（' + result.slides + ' 页' + missing + '）');
    } catch (error) {
      errors.push(root + '：' + error.message);
    }
  }
  for (let i = 0; i < html.length; i++) {
    const file = html[i];
    message('status', '正在导入 ' + (i + 1) + ' / ' + html.length + ' · ' + file.name);
    try {
      const result = await post('./api/import?' + new URLSearchParams({name:file.name}), file, 'application/octet-stream');
      if (result.duplicate) duplicates++;
      else added++;
    } catch (e) {
      errors.push(file.name + '：' + e.message);
    }
  }
  const parts = [added + ' 个已导入'];
  if (added) parts.push('已放入「待归类」');
  if (duplicates) parts.push(duplicates + ' 个重复');
  if (!manifests.length && files.length > html.length) parts.push((files.length - html.length) + ' 个非 HTML 已跳过');
  if (errors.length) parts.push(errors.length + ' 个失败');
  message('status', [parts.join(' · '), ...decks, ...errors.slice(0,3)].join('\n'), errors.length > 0);
  importing = $('pick').disabled = $('pickFolder').disabled = false;
  if (added) $('search').value = '';
  select(added ? pending : category);
}
$('ai').onclick = () => {
  if (!state) return;
  if (discussionAvailable) return openDiscussion('organize');
  $('prompt').value = '请用 html-cards-organize 技能整理 HTML 卡片库的待归类卡片。按现有类别归类、补充标签，并根据内容重命名文件。文件名已经贴切的保留，材料不足的继续留在待归类。';
  message('aiStatus', '');
  $('aiDialog').showModal();
};
$('copy').onclick = async () => {
  try {
    await navigator.clipboard.writeText($('prompt').value);
    message('aiStatus', '已复制，可粘贴到 DSH 对话。');
  } catch {
    $('prompt').select();
    message('aiStatus', '已选中指令，请手动复制。');
  }
};
function openDiscussion(mode, id, version) {
  window.parent.postMessage({ channel: chatChannel, type: 'open', mode, id, version }, window.location.origin === 'null' ? '*' : window.location.origin);
}
function updateHost(type, data) {
  window.parent.postMessage({ channel: chatChannel, type, ...data }, window.location.origin === 'null' ? '*' : window.location.origin);
}
function setReleaseStatus(status) {
  checkingRelease = false;
  releaseChecked = true;
  release = { ...release, latest: null, native: false, ...status };
  const { installed, latest, native, incompatible, error, releases } = release;
  const current = installed ? '当前版本 ' + installed + '。' : '';
  $('versionButton').textContent = latest ? '可更新到 ' + latest : (installed ? 'v' + installed + ' · 版本与更新' : '版本与更新');
  $('versionButton').toggleAttribute('data-available', Boolean(latest));
  $('checkUpdate').disabled = false;
  $('installUpdate').hidden = !(latest && native);
  $('installUpdate').textContent = '升级到 ' + (latest ?? '');
  if (releases) {
    $('releaseLink').href = latest ? releases + '/tag/v' + latest : releases;
    $('releaseLink').textContent = latest && !native ? '下载新版 ↗' : '发行说明 ↗';
    $('releaseLink').hidden = false;
  }
  const detail = latest
    ? (native ? '可升级到 ' + latest + '。点击升级后，DSH 将安装新版。'
      : '已有新版 ' + latest + '。请下载新版安装包，并在 DSH 插件页按发行说明升级。')
    : (incompatible ? '有新版本需要先更新 DSH。' : '已是最新版本。');
  $('updateMessage').textContent = current + (error || detail);
}
async function checkRelease() {
  if (checkingRelease || installingRelease) return;
  checkingRelease = true;
  $('checkUpdate').disabled = true;
  $('installUpdate').hidden = true;
  $('updateMessage').textContent = '正在检查更新…';
  if (discussionAvailable) {
    updateHost('check-update');
    return;
  }
  try {
    const latest = await request('./api/release/latest');
    setReleaseStatus(latest);
  } catch (error) {
    setReleaseStatus({ error: error.message });
  }
}
$('versionButton').onclick = () => {
  $('updateDialog').showModal();
  if (!releaseChecked) checkRelease();
};
$('checkUpdate').onclick = checkRelease;
$('installUpdate').onclick = () => {
  if (!release?.native || !release.latest || installingRelease) return;
  installingRelease = true;
  $('checkUpdate').disabled = $('installUpdate').disabled = true;
  $('updateMessage').textContent = '正在通过 DSH 安装 ' + release.latest + '…';
  updateHost('install-update');
};
$('discussion').onclick = () => openDiscussion('chat');
$('askCard').onclick = () => { if (readerItem) openDiscussion('card', readerItem.id); };
$('exportImages').onclick = () => {
  if (!readerItem || !exportAvailable || exportingId) return;
  exportingId = readerItem.id;
  $('exportImages').disabled = true;
  exportMessage('正在准备图片…');
  window.parent.postMessage({
    channel: chatChannel, type: 'export-images', id: exportingId, title: readerItem.title,
    ...activeAppearance(),
    width: $('frame').clientWidth, height: $('frame').clientHeight,
  }, window.location.origin === 'null' ? '*' : window.location.origin);
};
window.addEventListener('message', event => {
  if (window.parent === window || event.source !== window.parent || event.origin !== window.location.origin || event.data?.channel !== chatChannel) return;
  if (event.data.type === 'connect') {
    syncWorkspaceTheme();
    discussionAvailable = true;
    exportAvailable = event.data.canExport === true;
    $('exportImages').hidden = !exportAvailable || $('renderPanel').hidden;
    $('discussion').hidden = $('askCard').hidden = $('generateSummary').hidden = false;
    $('browseStorage').hidden = event.data.canBrowse !== true;
    checkRelease();
  } else if (event.data.type === 'storage-directory') {
    setStorageBusy(false);
    if (typeof event.data.directory === 'string') {
      $('storagePath').value = event.data.directory;
      message('storageStatus', '');
    }
    if (event.data.error) message('storageStatus', event.data.error, true);
  } else if (event.data.type === 'update-status') {
    setReleaseStatus(event.data);
  } else if (event.data.type === 'update-finished') {
    installingRelease = false;
    $('checkUpdate').disabled = $('installUpdate').disabled = false;
    $('installUpdate').hidden = true;
    $('updateMessage').textContent = event.data.message;
  } else if (['export-progress', 'export-done'].includes(event.data.type) && exportingId === event.data.id) {
    if (readerItem?.id === exportingId) exportMessage(event.data.message, event.data.error);
    if (event.data.type === 'export-done') {
      exportingId = undefined;
      $('exportImages').disabled = false;
    }
  } else if (event.data.type === 'refresh') {
    if (!importing) refresh();
    if (summaryEditor?.saved || !$('summaryPanel').hidden) loadSummary();
  }
});
window.addEventListener('focus', () => {
  if (!importing) refresh();
  if (!$('summaryPanel').hidden) loadSummary();
});
followTheme();
refresh();
if (window.parent === window) checkRelease();
